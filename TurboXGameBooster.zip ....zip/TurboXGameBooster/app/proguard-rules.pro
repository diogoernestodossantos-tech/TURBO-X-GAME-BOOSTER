# Regras de ProGuard/R8 do Turbo X Game Booster.
# O app não usa reflexão própria; as regras padrão do AGP e das bibliotecas AndroidX são suficientes.
