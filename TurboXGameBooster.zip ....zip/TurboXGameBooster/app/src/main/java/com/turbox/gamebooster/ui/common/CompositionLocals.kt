package com.turbox.gamebooster.ui.common

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.turbox.gamebooster.di.AppContainer
import com.turbox.gamebooster.viewmodel.TurboXViewModelFactory

val LocalAppContainer = staticCompositionLocalOf<AppContainer> {
    error("AppContainer não fornecido")
}

val LocalSnackbar = compositionLocalOf<SnackbarHostState> {
    error("SnackbarHostState não fornecido")
}

/** Cria/recupera um ViewModel do projeto com a fábrica baseada no AppContainer. */
@Composable
inline fun <reified VM : ViewModel> turboViewModel(): VM {
    val container = LocalAppContainer.current
    val factory = remember(container) { TurboXViewModelFactory(container) }
    return viewModel(factory = factory)
}

/** Espaçamento padrão das telas: respeita a barra de status (tela em modo edge-to-edge). */
@Composable
fun rememberScreenPadding(): PaddingValues {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    return PaddingValues(start = 16.dp, end = 16.dp, top = top + 16.dp, bottom = 24.dp)
}
