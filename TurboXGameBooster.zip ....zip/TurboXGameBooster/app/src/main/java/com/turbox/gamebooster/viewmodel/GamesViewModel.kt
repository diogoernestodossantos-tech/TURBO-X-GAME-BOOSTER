package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turbox.gamebooster.model.GameItem
import com.turbox.gamebooster.model.InstalledApp
import com.turbox.gamebooster.model.LaunchResult
import com.turbox.gamebooster.repository.GameRepository
import com.turbox.gamebooster.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GamesUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val games: List<GameItem> = emptyList(),
    /** Apps visíveis que ainda não estão na biblioteca (para adicionar manualmente). */
    val addableApps: List<InstalledApp> = emptyList(),
    val selectedPackage: String? = null,
    val message: String? = null
)

class GamesViewModel(
    private val gameRepository: GameRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private data class LocalState(
        val isLoading: Boolean = true,
        val error: String? = null,
        val selected: String? = null,
        val message: String? = null
    )

    private val local = MutableStateFlow(LocalState())

    val uiState: StateFlow<GamesUiState> = combine(
        settingsRepository.settings,
        gameRepository.installedApps,
        local
    ) { settings, apps, state ->
        val items = apps
            .filter { it.declaredGame || it.packageName in settings.customGames }
            .map { app ->
                GameItem(
                    app = app,
                    isFavorite = app.packageName in settings.favorites,
                    isCustom = !app.declaredGame && app.packageName in settings.customGames
                )
            }
            .sortedWith(compareByDescending<GameItem> { it.isFavorite }.thenBy { it.app.label.lowercase() })
        val inLibrary = items.map { it.app.packageName }.toSet()
        GamesUiState(
            isLoading = state.isLoading,
            error = state.error,
            games = items,
            addableApps = apps.filter { it.packageName !in inLibrary },
            selectedPackage = state.selected,
            message = state.message
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GamesUiState())

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            local.update { it.copy(isLoading = true, error = null) }
            val result = gameRepository.refresh()
            local.update {
                it.copy(
                    isLoading = false,
                    error = result.exceptionOrNull()?.let { e ->
                        "Não foi possível ler os apps instalados: ${e.message ?: "erro desconhecido"}"
                    }
                )
            }
        }
    }

    fun select(packageName: String) {
        local.update { it.copy(selected = if (it.selected == packageName) null else packageName) }
    }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch { settingsRepository.toggleFavorite(packageName) }
    }

    fun addCustomGame(packageName: String) {
        viewModelScope.launch {
            settingsRepository.addCustomGame(packageName)
            local.update { it.copy(selected = packageName) }
        }
    }

    fun removeCustomGame(packageName: String) {
        viewModelScope.launch {
            settingsRepository.removeCustomGame(packageName)
            local.update { it.copy(selected = null) }
        }
    }

    fun launch(packageName: String) {
        when (val result = gameRepository.launch(packageName)) {
            LaunchResult.Success -> viewModelScope.launch { settingsRepository.pushRecentGame(packageName) }
            LaunchResult.NotLaunchable -> postMessage(
                "Não foi possível abrir este jogo: ele não tem tela inicial ou foi desinstalado."
            )
            is LaunchResult.Failed -> postMessage("Não foi possível abrir o jogo: ${result.reason}")
        }
    }

    private fun postMessage(text: String) {
        local.update { it.copy(message = text) }
    }

    fun consumeMessage() {
        local.update { it.copy(message = null) }
    }
}
