package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.OptimizationProfile
import com.turbox.gamebooster.model.SettingsTarget
import com.turbox.gamebooster.ui.common.LocalSnackbar
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.components.GlowButton
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.StatusChip
import com.turbox.gamebooster.ui.navigation.Routes
import com.turbox.gamebooster.ui.theme.TurboGreen
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.util.SystemSettings
import com.turbox.gamebooster.viewmodel.OptimizationViewModel

@Composable
fun OptimizationScreen(onOpen: (String) -> Unit) {
    val viewModel: OptimizationViewModel = turboViewModel()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    val context = LocalContext.current

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    val current = settings

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader(title = "Otimização", subtitle = "Escolha um perfil de jogo") }
        item { LimitsNote() }

        if (current == null) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TurboRed)
                }
            }
        } else {
            items(OptimizationProfile.entries.toList(), key = { it.id }) { profile ->
                ProfileCard(
                    profile = profile,
                    settings = current,
                    active = profile == current.activeProfile,
                    onActivate = { viewModel.activate(profile) },
                    onOpenSettings = { SystemSettings.open(context, it) }
                )
            }
        }

        item {
            NeonCard(onClick = { onOpen(Routes.STORAGE) }) {
                ToolRow(Icons.Filled.DeleteSweep, "Armazenamento", "Veja o espaço livre e libere espaço com segurança")
            }
        }
        item {
            NeonCard(onClick = { onOpen(Routes.FPS) }) {
                ToolRow(Icons.Filled.Timeline, "FPS Monitor", "O que dá (e o que não dá) para medir no Android")
            }
        }
    }
}

@Composable
private fun LimitsNote() {
    NeonCard {
        Text("O que um perfil faz", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            text = "O Android não deixa apps comuns alterarem CPU, GPU, memória ou FPS. Por isso o perfil ajusta " +
                "os limites de alerta do Turbo Mode e mostra recomendações, com atalhos para as configurações " +
                "do sistema onde você mesmo aplica cada ajuste.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ProfileCard(
    profile: OptimizationProfile,
    settings: AppSettings,
    active: Boolean,
    onActivate: () -> Unit,
    onOpenSettings: (SettingsTarget) -> Unit
) {
    val preview = settings.copy(activeProfile = profile)
    NeonCard(glow = active) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(profile.title.uppercase(), style = MaterialTheme.typography.titleLarge)
                Text(
                    profile.tagline,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (active) StatusChip("ATIVO", TurboGreen)
        }
        Spacer(Modifier.height(10.dp))
        Text(profile.description, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Alertas do Turbo Mode: bateria a partir de ${preview.effectiveTempWarnCelsius} °C · " +
                "RAM a partir de ${preview.effectiveRamWarnPercent}%.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        profile.tips.forEach { tip ->
            Row(modifier = Modifier.padding(vertical = 3.dp)) {
                Text("•", color = TurboRed, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(tip.text, style = MaterialTheme.typography.bodyMedium)
                    val target = tip.target
                    if (target != null) {
                        TextButton(onClick = { onOpenSettings(target) }) {
                            Text("Abrir ${target.label}", color = TurboRed)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        GlowButton(
            text = if (active) "Perfil ativo" else "Ativar perfil",
            onClick = onActivate,
            modifier = Modifier.fillMaxWidth(),
            icon = if (active) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
            enabled = !active
        )
    }
}

@Composable
private fun ToolRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = TurboRed)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
