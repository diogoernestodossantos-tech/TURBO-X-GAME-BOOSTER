package com.turbox.gamebooster.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.turbox.gamebooster.ui.screens.FpsMonitorScreen
import com.turbox.gamebooster.ui.screens.GamesScreen
import com.turbox.gamebooster.ui.screens.HomeScreen
import com.turbox.gamebooster.ui.screens.MonitorScreen
import com.turbox.gamebooster.ui.screens.OptimizationScreen
import com.turbox.gamebooster.ui.screens.PrivacyScreen
import com.turbox.gamebooster.ui.screens.SettingsScreen
import com.turbox.gamebooster.ui.screens.StorageScreen

private val tabRoutes = TopLevelTabs.map { it.route }.toSet()

/** Troca de aba preservando o estado de cada uma. */
fun NavHostController.navigateToTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Abre uma aba ou uma tela secundária. */
fun NavHostController.openRoute(route: String) {
    if (route in tabRoutes) {
        navigateToTab(route)
    } else {
        navigate(route) { launchSingleTop = true }
    }
}

@Composable
fun TurboNavHost(navController: NavHostController, modifier: Modifier = Modifier) {
    val open: (String) -> Unit = { navController.openRoute(it) }
    val back: () -> Unit = { navController.popBackStack() }

    NavHost(navController = navController, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) { Screen { HomeScreen(onOpen = open) } }
        composable(Routes.GAMES) { Screen { GamesScreen() } }
        composable(Routes.OPTIMIZATION) { Screen { OptimizationScreen(onOpen = open) } }
        composable(Routes.MONITOR) { Screen { MonitorScreen(onOpen = open) } }
        composable(Routes.SETTINGS) { Screen { SettingsScreen(onOpen = open) } }
        composable(Routes.STORAGE) { Screen { StorageScreen(onBack = back) } }
        composable(Routes.FPS) { Screen { FpsMonitorScreen(onBack = back) } }
        composable(Routes.PRIVACY) { Screen { PrivacyScreen(onBack = back) } }
    }
}

@Composable
private fun Screen(content: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) { content() }
}
