package com.turbox.gamebooster.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Speed
import androidx.compose.ui.graphics.vector.ImageVector

object Routes {
    const val HOME = "home"
    const val GAMES = "games"
    const val OPTIMIZATION = "optimization"
    const val MONITOR = "monitor"
    const val SETTINGS = "settings"

    // Telas secundárias (abertas por atalhos, fora da barra inferior)
    const val STORAGE = "storage"
    const val FPS = "fps"
    const val PRIVACY = "privacy"
}

data class TabItem(val route: String, val label: String, val icon: ImageVector)

val TopLevelTabs = listOf(
    TabItem(Routes.HOME, "Home", Icons.Filled.Home),
    TabItem(Routes.GAMES, "Meus Jogos", Icons.Filled.SportsEsports),
    TabItem(Routes.OPTIMIZATION, "Otimização", Icons.Filled.Speed),
    TabItem(Routes.MONITOR, "Monitoramento", Icons.Filled.MonitorHeart),
    TabItem(Routes.SETTINGS, "Configurações", Icons.Filled.Settings)
)
