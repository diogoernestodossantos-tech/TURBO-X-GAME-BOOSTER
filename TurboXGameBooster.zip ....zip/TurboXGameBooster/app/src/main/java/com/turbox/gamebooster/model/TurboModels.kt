package com.turbox.gamebooster.model

enum class StepStatus { OK, ATTENTION, INFO, UNAVAILABLE }

/** Resultado de uma verificação real do Turbo Mode. */
data class TurboStep(
    val title: String,
    val detail: String,
    val status: StepStatus,
    /** Recomendação exibida quando [status] é ATTENTION. */
    val hint: String? = null,
    /** Tela de configurações do Android que ajuda a resolver o ponto de atenção. */
    val action: SettingsTarget? = null
)

sealed interface TurboState {
    data object Idle : TurboState
    data class Running(val steps: List<TurboStep>) : TurboState
    data class Done(val steps: List<TurboStep>) : TurboState
    data class Failed(val message: String, val steps: List<TurboStep>) : TurboState
}
