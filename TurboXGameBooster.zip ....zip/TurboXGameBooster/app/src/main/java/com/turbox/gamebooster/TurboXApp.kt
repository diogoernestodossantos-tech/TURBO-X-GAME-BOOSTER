package com.turbox.gamebooster

import android.app.Application
import com.turbox.gamebooster.di.AppContainer

class TurboXApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
