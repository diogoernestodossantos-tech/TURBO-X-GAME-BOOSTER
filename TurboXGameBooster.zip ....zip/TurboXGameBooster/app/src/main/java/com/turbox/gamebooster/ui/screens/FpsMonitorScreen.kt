package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.components.InfoRow
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.SectionTitle
import com.turbox.gamebooster.ui.theme.TurboAmber
import com.turbox.gamebooster.ui.theme.TurboGreen
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.viewmodel.MonitorViewModel
import java.util.Locale

/**
 * FPS MONITOR — apenas informativo, de propósito.
 *
 * O Android não oferece a apps comuns nenhuma API para ler o FPS de OUTRO app/jogo
 * (Choreographer e FrameMetrics só medem a própria janela do app que os usa; ferramentas
 * como dumpsys/gfxinfo exigem ADB ou permissões de sistema). Por isso esta tela NÃO exibe
 * contador de FPS: mostra a taxa de atualização real da tela e explica as alternativas.
 */
@Composable
fun FpsMonitorScreen(onBack: () -> Unit) {
    val viewModel: MonitorViewModel = turboViewModel()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val display = state.snapshot?.display

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader(title = "FPS Monitor", subtitle = "O que é possível medir", onBack = onBack) }

        item {
            NeonCard(glow = true) {
                Row {
                    Icon(Icons.Filled.Block, contentDescription = null, tint = TurboRed)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Contador de FPS indisponível", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "O Android não permite que um app comum meça o FPS de outros jogos. " +
                                "Por isso o Turbo X não mostra nenhum número de FPS: qualquer valor exibido " +
                                "aqui seria inventado.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            NeonCard {
                SectionTitle("Dado real: sua tela")
                if (display == null) {
                    Text(
                        "Aguardando leitura da tela…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    InfoRow("Taxa de atualização agora", String.format(Locale.getDefault(), "%.0f Hz", display.currentRefreshRateHz))
                    InfoRow("Modos suportados", display.supportedRefreshRatesHz.joinToString(", ") { "$it Hz" })
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Isso é a capacidade da tela (quantas vezes por segundo ela pode atualizar), não os quadros " +
                        "que o jogo está gerando. Um jogo pode rodar a menos FPS do que a tela suporta.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            NeonCard {
                SectionTitle("Métodos de medição")
                MethodRow(
                    icon = Icons.Filled.CheckCircle, tint = TurboGreen,
                    title = "Taxa de atualização da tela",
                    text = "Suportado. É o que mostramos acima, via DisplayManager."
                )
                MethodRow(
                    icon = Icons.Filled.CheckCircle, tint = TurboGreen,
                    title = "Medidor do próprio jogo",
                    text = "Suportado. Muitos jogos têm um contador de FPS nas configurações ou no menu de desempenho."
                )
                MethodRow(
                    icon = Icons.Filled.Info, tint = TurboAmber,
                    title = "Ferramentas do sistema",
                    text = "Em alguns aparelhos há um painel de desempenho de jogos nas configurações do fabricante " +
                        "ou nas opções do desenvolvedor (por exemplo, perfil de renderização da GPU). Varia por marca."
                )
                MethodRow(
                    icon = Icons.Filled.Info, tint = TurboAmber,
                    title = "Medição via computador",
                    text = "Com depuração USB e ferramentas como o Android Studio (Profiler), é possível medir o desempenho " +
                        "de um app. Isso é feito fora do aparelho e o Turbo X não usa ADB."
                )
                MethodRow(
                    icon = Icons.Filled.Block, tint = TurboRed,
                    title = "FPS de outro jogo por este app",
                    text = "Não suportado. Choreographer e FrameMetrics só enxergam a própria janela do app que os usa."
                )
            }
        }

        item {
            NeonCard {
                SectionTitle("Alternativas para o jogador")
                listOf(
                    "Ative o contador de FPS do próprio jogo, se existir.",
                    "Observe a sensação de fluidez e use o perfil Estabilidade para sessões longas.",
                    "Se o jogo travar, reduza resolução, sombras e efeitos nas configurações gráficas dele.",
                    "Confira no Monitoramento se RAM e temperatura da bateria estão dentro do limite."
                ).forEach {
                    Text("• $it", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 3.dp))
                }
            }
        }
    }
}

@Composable
private fun MethodRow(icon: ImageVector, tint: Color, title: String, text: String) {
    Row(modifier = Modifier.padding(vertical = 6.dp)) {
        Icon(icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
