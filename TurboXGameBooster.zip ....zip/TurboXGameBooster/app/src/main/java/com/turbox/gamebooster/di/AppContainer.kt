package com.turbox.gamebooster.di

import android.content.Context
import com.turbox.gamebooster.repository.DeviceRepository
import com.turbox.gamebooster.repository.GameRepository
import com.turbox.gamebooster.repository.SettingsRepository
import com.turbox.gamebooster.repository.turboDataStore
import com.turbox.gamebooster.service.GameScanner
import com.turbox.gamebooster.service.SystemMonitor
import com.turbox.gamebooster.service.TurboModeRunner

/** Injeção de dependências manual (suficiente para este projeto, sem framework extra). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    private val systemMonitor = SystemMonitor(appContext)
    private val gameScanner = GameScanner(appContext)

    val settingsRepository = SettingsRepository(appContext.turboDataStore)
    val deviceRepository = DeviceRepository(systemMonitor, settingsRepository)
    val gameRepository = GameRepository(gameScanner)
    val turboModeRunner = TurboModeRunner(systemMonitor)
}
