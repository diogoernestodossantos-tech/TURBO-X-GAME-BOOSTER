package com.turbox.gamebooster.repository

import com.turbox.gamebooster.model.DeviceInfo
import com.turbox.gamebooster.model.DeviceSnapshot
import com.turbox.gamebooster.service.SystemMonitor
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map

class DeviceRepository(
    private val monitor: SystemMonitor,
    private val settingsRepository: SettingsRepository
) {

    /** Leituras periódicas; o intervalo vem das configurações e é reaplicado quando muda. */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun liveSnapshots(): Flow<DeviceSnapshot> =
        settingsRepository.settings
            .map { it.monitorIntervalSeconds }
            .distinctUntilChanged()
            .flatMapLatest { seconds -> monitor.snapshots(seconds * 1000L) }

    fun deviceInfo(): DeviceInfo = monitor.readDeviceInfo()
}
