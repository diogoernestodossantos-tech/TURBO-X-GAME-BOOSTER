@file:OptIn(ExperimentalMaterial3Api::class)

package com.turbox.gamebooster.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.model.GameItem
import com.turbox.gamebooster.model.InstalledApp
import com.turbox.gamebooster.ui.common.LocalSnackbar
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.components.AppIcon
import com.turbox.gamebooster.ui.components.GlowButton
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.StatusChip
import com.turbox.gamebooster.ui.theme.TurboAmber
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.viewmodel.GamesViewModel

@Composable
fun GamesScreen() {
    val viewModel: GamesViewModel = turboViewModel()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    var showPicker by remember { mutableStateOf(false) }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenHeader(
                title = "Meus Jogos",
                subtitle = "Biblioteca de jogos instalados",
                actions = {
                    IconButton(onClick = viewModel::refresh) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Atualizar lista")
                    }
                }
            )
        }
        item {
            Text(
                text = "O Turbo X mostra os apps que se declaram como jogo no Android e que ele consegue enxergar. " +
                    "Se algum jogo não aparecer, adicione-o manualmente.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        when {
            state.isLoading -> item {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TurboRed)
                }
            }

            state.error != null -> item {
                NeonCard {
                    Text(state.error ?: "", color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = viewModel::refresh) { Text("Tentar de novo", color = TurboRed) }
                }
            }

            state.games.isEmpty() -> item {
                NeonCard {
                    Text("Nenhum jogo encontrado", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Nenhum app visível se declara como jogo. Use o botão abaixo para escolher seus jogos na lista de apps.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            else -> items(state.games, key = { it.app.packageName }) { game ->
                GameRow(
                    game = game,
                    selected = state.selectedPackage == game.app.packageName,
                    onSelect = { viewModel.select(game.app.packageName) },
                    onLaunch = { viewModel.launch(game.app.packageName) },
                    onFavorite = { viewModel.toggleFavorite(game.app.packageName) },
                    onRemove = { viewModel.removeCustomGame(game.app.packageName) }
                )
            }
        }

        item {
            GlowButton(
                text = "Adicionar jogo manualmente",
                onClick = { showPicker = true },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Filled.Add,
                enabled = !state.isLoading
            )
        }
    }

    if (showPicker) {
        AppPickerSheet(
            candidates = state.addableApps,
            onPick = {
                viewModel.addCustomGame(it.packageName)
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
private fun GameRow(
    game: GameItem,
    selected: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit,
    onFavorite: () -> Unit,
    onRemove: () -> Unit
) {
    NeonCard(glow = selected, onClick = onSelect, modifier = Modifier.animateContentSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(game.app.packageName, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = game.app.label,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (game.isFavorite || game.isCustom) {
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (game.isFavorite) StatusChip("Favorito", TurboAmber)
                        if (game.isCustom) StatusChip("Adicionado por você", MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (selected) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                GlowButton(
                    text = "Abrir jogo",
                    onClick = onLaunch,
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.PlayArrow
                )
                IconButton(onClick = onFavorite) {
                    Icon(
                        imageVector = if (game.isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (game.isFavorite) "Remover dos favoritos" else "Adicionar aos favoritos",
                        tint = if (game.isFavorite) TurboAmber else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (game.isCustom) {
                    IconButton(onClick = onRemove) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remover da biblioteca")
                    }
                }
            }
        }
    }
}

@Composable
private fun AppPickerSheet(
    candidates: List<InstalledApp>,
    onPick: (InstalledApp) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(candidates, query) {
        candidates.filter { it.label.contains(query, ignoreCase = true) }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .navigationBarsPadding()
        ) {
            Text("Adicionar à biblioteca", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                "Apps visíveis ao Turbo X. Toque em um app para tratá-lo como jogo.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar app") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                Text(
                    "Nenhum app encontrado.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    items(filtered, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.packageName, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                app.label,
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
