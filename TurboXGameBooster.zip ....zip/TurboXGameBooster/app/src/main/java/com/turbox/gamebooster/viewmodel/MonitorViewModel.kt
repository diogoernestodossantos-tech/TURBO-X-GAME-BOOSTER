package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.DeviceInfo
import com.turbox.gamebooster.model.DeviceSnapshot
import com.turbox.gamebooster.repository.DeviceRepository
import com.turbox.gamebooster.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class MonitorUiState(
    /** Null enquanto a primeira leitura não chegou (estado de carregamento). */
    val snapshot: DeviceSnapshot? = null,
    val deviceInfo: DeviceInfo,
    val settings: AppSettings = AppSettings()
)

/** Usado pelas telas Monitoramento, Armazenamento e FPS Monitor. A coleta só roda com a tela visível. */
class MonitorViewModel(
    deviceRepository: DeviceRepository,
    settingsRepository: SettingsRepository
) : ViewModel() {

    private val deviceInfo = deviceRepository.deviceInfo()

    val uiState: StateFlow<MonitorUiState> = combine(
        deviceRepository.liveSnapshots(),
        settingsRepository.settings
    ) { snapshot, settings ->
        MonitorUiState(snapshot = snapshot, deviceInfo = deviceInfo, settings = settings)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MonitorUiState(deviceInfo = deviceInfo))
}
