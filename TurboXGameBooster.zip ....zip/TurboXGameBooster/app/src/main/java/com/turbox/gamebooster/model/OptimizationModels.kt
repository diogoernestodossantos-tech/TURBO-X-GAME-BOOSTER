package com.turbox.gamebooster.model

/** Telas do Android que o app consegue abrir para o usuário aplicar um ajuste por conta própria. */
enum class SettingsTarget(val label: String) {
    DISPLAY("configurações de tela"),
    BATTERY_SAVER("economia de bateria"),
    STORAGE("armazenamento"),
    SOUND_DND("som e Não perturbe"),
    WIFI("Wi-Fi"),
    APPS("lista de apps"),
    DEVELOPER("opções do desenvolvedor")
}

data class ProfileTip(
    val text: String,
    val target: SettingsTarget? = null
)

/**
 * Perfis de jogo. Um perfil NÃO altera CPU, GPU, memória ou FPS (o Android não permite isso a apps comuns).
 * O que ele realmente muda no app:
 *  1) os limites de alerta de temperatura e RAM usados no Turbo Mode ([tempWarnDelta], [ramWarnDelta]);
 *  2) as recomendações exibidas, com atalhos para as telas de configuração do sistema.
 */
enum class OptimizationProfile(
    val id: String,
    val title: String,
    val tagline: String,
    val description: String,
    val tempWarnDelta: Int,
    val ramWarnDelta: Int,
    val tips: List<ProfileTip>
) {
    BALANCED(
        id = "balanced",
        title = "Equilibrado",
        tagline = "Estabilidade com bateria sob controle",
        description = "Prioriza estabilidade sem gastar bateria à toa. Indicado para o uso diário e sessões curtas. " +
            "Usa os limites de alerta padrão definidos em Configurações.",
        tempWarnDelta = 0,
        ramWarnDelta = 0,
        tips = listOf(
            ProfileTip("Mantenha o brilho em automático e evite jogar com o carregador conectado.", SettingsTarget.DISPLAY),
            ProfileTip("Use a predefinição gráfica Média no jogo e limite o FPS se o jogo oferecer essa opção."),
            ProfileTip("Deixe a economia de bateria desligada durante a partida e ligue depois.", SettingsTarget.BATTERY_SAVER),
            ProfileTip("Mantenha pelo menos 10% do armazenamento livre.", SettingsTarget.STORAGE)
        )
    ),
    PERFORMANCE(
        id = "performance",
        title = "Desempenho",
        tagline = "Mais fluidez, com ajustes feitos por você",
        description = "Para quando você quer a melhor fluidez que o aparelho consegue entregar. O Turbo X não mexe em CPU ou GPU; " +
            "ele orienta os ajustes de gráficos e de sistema que você mesmo aplica. Usa os limites de alerta padrão.",
        tempWarnDelta = 0,
        ramWarnDelta = 0,
        tips = listOf(
            ProfileTip("Se o jogo engasga, reduza resolução, sombras, antisserrilhado e efeitos nas configurações gráficas dele."),
            ProfileTip("Desative a economia de bateria enquanto joga: ela pode limitar o desempenho.", SettingsTarget.BATTERY_SAVER),
            ProfileTip("Em telas de alta taxa de atualização, confira se o aparelho não está travado no modo de 60 Hz.", SettingsTarget.DISPLAY),
            ProfileTip("Ative o Não perturbe para notificações não interromperem a partida.", SettingsTarget.SOUND_DND),
            ProfileTip("Em jogos online, prefira um Wi-Fi estável.", SettingsTarget.WIFI),
            ProfileTip("Opcional: reduza as escalas de animação do sistema nas opções do desenvolvedor.", SettingsTarget.DEVELOPER)
        )
    ),
    STABILITY(
        id = "stability",
        title = "Estabilidade",
        tagline = "Consistência e temperatura sob controle",
        description = "Para sessões longas: menos picos e menos superaquecimento. Neste perfil o Turbo Mode avisa mais cedo: " +
            "o alerta de temperatura dispara 3 °C antes e o de RAM 5 pontos percentuais antes do limite padrão.",
        tempWarnDelta = -3,
        ramWarnDelta = -5,
        tips = listOf(
            ProfileTip("Feche manualmente apps pesados pela tela de Recentes antes de jogar."),
            ProfileTip("Reduza gráficos e limite o FPS dentro do jogo para evitar superaquecimento."),
            ProfileTip("Evite jogar carregando e retire a capa do aparelho se ele esquentar."),
            ProfileTip("Faça uma pausa quando a temperatura da bateria passar do limite de alerta."),
            ProfileTip("Ative o Não perturbe para evitar interrupções e picos de atividade em segundo plano.", SettingsTarget.SOUND_DND),
            ProfileTip("Mantenha o armazenamento com folga: aparelhos muito cheios tendem a ficar mais lentos.", SettingsTarget.STORAGE)
        )
    );

    companion object {
        fun fromId(id: String?): OptimizationProfile = entries.firstOrNull { it.id == id } ?: BALANCED
    }
}
