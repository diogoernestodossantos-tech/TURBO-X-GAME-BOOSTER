package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.turbox.gamebooster.di.AppContainer

class TurboXViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(
            container.deviceRepository,
            container.gameRepository,
            container.settingsRepository,
            container.turboModeRunner
        ) as T

        modelClass.isAssignableFrom(GamesViewModel::class.java) -> GamesViewModel(
            container.gameRepository,
            container.settingsRepository
        ) as T

        modelClass.isAssignableFrom(OptimizationViewModel::class.java) -> OptimizationViewModel(
            container.settingsRepository
        ) as T

        modelClass.isAssignableFrom(MonitorViewModel::class.java) -> MonitorViewModel(
            container.deviceRepository,
            container.settingsRepository
        ) as T

        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(
            container.settingsRepository
        ) as T

        else -> throw IllegalArgumentException("ViewModel desconhecido: ${modelClass.name}")
    }
}
