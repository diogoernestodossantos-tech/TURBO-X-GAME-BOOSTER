package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.OptimizationProfile
import com.turbox.gamebooster.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

class OptimizationViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    /** Null enquanto as preferências ainda estão sendo carregadas. */
    val settings: StateFlow<AppSettings?> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun activate(profile: OptimizationProfile) {
        viewModelScope.launch {
            _message.value = try {
                settingsRepository.setProfile(profile)
                "Perfil ${profile.title} ativado."
            } catch (e: IOException) {
                "Não foi possível salvar o perfil: ${e.message ?: "erro ao gravar"}"
            }
        }
    }

    fun consumeMessage() {
        _message.value = null
    }
}
