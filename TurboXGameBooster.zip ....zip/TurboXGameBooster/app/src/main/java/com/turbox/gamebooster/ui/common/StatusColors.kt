package com.turbox.gamebooster.ui.common

import androidx.compose.ui.graphics.Color
import com.turbox.gamebooster.ui.theme.TurboAmber
import com.turbox.gamebooster.ui.theme.TurboGreen
import com.turbox.gamebooster.ui.theme.TurboRed

/** Quanto MAIOR o uso, pior. Usado para RAM em uso. */
fun usageColor(usedFraction: Float, warnPercent: Int): Color {
    val used = usedFraction * 100f
    return when {
        used >= warnPercent -> TurboRed
        used >= warnPercent - 15 -> TurboAmber
        else -> TurboGreen
    }
}

/** Quanto MENOR o nível, pior. Usado para bateria. */
fun batteryLevelColor(percent: Int?): Color = when {
    percent == null -> TurboAmber
    percent >= 50 -> TurboGreen
    percent >= 20 -> TurboAmber
    else -> TurboRed
}

/** Temperatura da bateria em relação ao limite de alerta. */
fun temperatureColor(celsius: Float?, warnCelsius: Int): Color = when {
    celsius == null -> TurboAmber
    celsius >= warnCelsius -> TurboRed
    celsius >= warnCelsius - 5 -> TurboAmber
    else -> TurboGreen
}
