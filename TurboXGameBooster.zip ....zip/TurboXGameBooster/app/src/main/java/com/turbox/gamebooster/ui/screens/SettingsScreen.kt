package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.BuildConfig
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.ui.common.LocalSnackbar
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.components.GlowButton
import com.turbox.gamebooster.ui.components.InfoRow
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.SectionTitle
import com.turbox.gamebooster.ui.navigation.Routes
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.viewmodel.SettingsViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onOpen: (String) -> Unit) {
    val viewModel: SettingsViewModel = turboViewModel()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    var confirmReset by remember { mutableStateOf(false) }
    var confirmLibrary by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    val current = settings

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader(title = "Configurações", subtitle = "Preferências do Turbo X") }

        if (current == null) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TurboRed)
                }
            }
            return@LazyColumn
        }

        item {
            NeonCard {
                SectionTitle("Aparência")
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Tema escuro", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Recomendado: economiza bateria em telas OLED e combina com o visual gamer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = current.darkTheme,
                        onCheckedChange = viewModel::setDarkTheme,
                        colors = SwitchDefaults.colors(checkedTrackColor = TurboRed)
                    )
                }
            }
        }

        item {
            NeonCard {
                SectionTitle("Preferências de otimização")
                Text(
                    "Perfil ativo: ${current.activeProfile.title} (troque na aba Otimização).",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))

                OptionGroup(
                    title = "Atualização do monitoramento",
                    subtitle = "Intervalos maiores gastam menos bateria.",
                    options = AppSettings.INTERVAL_OPTIONS,
                    selected = current.monitorIntervalSeconds,
                    label = { "$it s" },
                    onSelect = viewModel::setMonitorInterval
                )
                OptionGroup(
                    title = "Alerta de temperatura da bateria",
                    subtitle = "O perfil Estabilidade avisa 3 °C antes.",
                    options = AppSettings.TEMP_OPTIONS,
                    selected = current.tempWarnCelsius,
                    label = { "$it °C" },
                    onSelect = viewModel::setTempWarn
                )
                OptionGroup(
                    title = "Alerta de RAM em uso",
                    subtitle = "O perfil Estabilidade avisa 5 pontos antes.",
                    options = AppSettings.RAM_OPTIONS,
                    selected = current.ramWarnPercent,
                    label = { "$it%" },
                    onSelect = viewModel::setRamWarn
                )
            }
        }

        item {
            NeonCard {
                SectionTitle("Informações do aplicativo")
                InfoRow("Aplicativo", "Turbo X Game Booster")
                InfoRow("Versão instalada", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                InfoRow("Permissões solicitadas", "Nenhuma")
                InfoRow("Dados enviados", "Nenhum (sem internet)")
                Spacer(Modifier.height(8.dp))
                GlowButton(
                    text = "Política de privacidade",
                    onClick = { onOpen(Routes.PRIVACY) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.PrivacyTip,
                    filled = false
                )
            }
        }

        item {
            NeonCard {
                SectionTitle("Redefinir")
                Text(
                    "Restaurar o padrão de tema, intervalo e limites de alerta. Seus favoritos e jogos adicionados são mantidos.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                GlowButton(
                    text = "Redefinir configurações",
                    onClick = { confirmReset = true },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.RestartAlt
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "Apagar favoritos, jogos adicionados manualmente e jogos recentes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                GlowButton(
                    text = "Limpar biblioteca",
                    onClick = { confirmLibrary = true },
                    modifier = Modifier.fillMaxWidth(),
                    filled = false
                )
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Redefinir configurações?",
            text = "Tema, intervalo, limites de alerta e perfil voltam ao padrão.",
            confirmLabel = "Redefinir",
            onConfirm = {
                viewModel.resetPreferences()
                confirmReset = false
            },
            onDismiss = { confirmReset = false }
        )
    }
    if (confirmLibrary) {
        ConfirmDialog(
            title = "Limpar biblioteca?",
            text = "Favoritos, jogos adicionados por você e a lista de recentes serão apagados. Nenhum app é desinstalado.",
            confirmLabel = "Limpar",
            onConfirm = {
                viewModel.resetLibrary()
                confirmLibrary = false
            },
            onDismiss = { confirmLibrary = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> OptionGroup(
    title: String,
    subtitle: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column(modifier = Modifier.padding(bottom = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { option ->
                FilterChip(
                    selected = option == selected,
                    onClick = { onSelect(option) },
                    label = { Text(label(option)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TurboRed.copy(alpha = 0.25f),
                        selectedLabelColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = TurboRed) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
