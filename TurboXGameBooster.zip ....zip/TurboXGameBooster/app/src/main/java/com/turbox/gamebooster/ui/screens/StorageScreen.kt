package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.model.SettingsTarget
import com.turbox.gamebooster.ui.common.LocalSnackbar
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.components.GlowButton
import com.turbox.gamebooster.ui.components.InfoRow
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.SectionTitle
import com.turbox.gamebooster.ui.theme.TurboAmber
import com.turbox.gamebooster.ui.theme.TurboGreen
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.util.SystemSettings
import com.turbox.gamebooster.util.formatBytes
import com.turbox.gamebooster.util.formatPercent
import com.turbox.gamebooster.viewmodel.MonitorViewModel
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun StorageScreen(onBack: () -> Unit) {
    val viewModel: MonitorViewModel = turboViewModel()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val storage = state.snapshot?.storage
    val context = LocalContext.current
    val snackbar = LocalSnackbar.current
    val scope = rememberCoroutineScope()

    fun open(target: SettingsTarget) {
        if (!SystemSettings.open(context, target)) {
            scope.launch { snackbar.showSnackbar("Não foi possível abrir as configurações neste aparelho.") }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader(title = "Armazenamento", subtitle = "Espaço livre e como liberar", onBack = onBack) }

        item {
            NeonCard(glow = true) {
                SectionTitle("Armazenamento interno")
                when {
                    state.snapshot == null -> Box(
                        Modifier.fillMaxWidth().padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) { CircularProgressIndicator(color = TurboRed) }

                    storage == null -> Text(
                        "Não foi possível ler o espaço de armazenamento deste aparelho.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )

                    else -> {
                        val low = storage.freeFraction < 0.10f
                        val color = when {
                            low -> TurboRed
                            storage.freeFraction < 0.20f -> TurboAmber
                            else -> TurboGreen
                        }
                        Text(
                            text = "${formatBytes(storage.freeBytes)} livres",
                            style = MaterialTheme.typography.headlineMedium,
                            color = color
                        )
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { storage.usedFraction },
                            modifier = Modifier.fillMaxWidth().height(10.dp),
                            color = color,
                            trackColor = MaterialTheme.colorScheme.outline
                        )
                        Spacer(Modifier.height(10.dp))
                        InfoRow("Total", formatBytes(storage.totalBytes))
                        InfoRow("Usado", "${formatBytes(storage.usedBytes)} (${formatPercent(storage.usedFraction)})")
                        InfoRow("Livre", "${formatBytes(storage.freeBytes)} (${formatPercent(storage.freeFraction)})")
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = when {
                                low -> "Pouco espaço livre pode causar lentidão e travamentos em jogos. Libere espaço."
                                storage.freeFraction < 0.20f -> "O espaço está ficando curto. Vale revisar arquivos e apps que você não usa."
                                else -> "Há espaço de sobra no momento."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            NeonCard {
                SectionTitle("Como liberar espaço com segurança")
                listOf(
                    "Abra o armazenamento do Android e use a opção de liberar espaço, quando existir.",
                    "Desinstale jogos e apps que você não usa mais (isso também apaga os dados deles).",
                    "Apague vídeos, downloads e capturas de tela antigos pelo app Arquivos ou Galeria.",
                    "Em Configurações > Apps, abra um app específico e use \"Limpar cache\" se ele estiver ocupando muito.",
                    "Faça backup de fotos e vídeos na nuvem ou no computador antes de apagá-los."
                ).forEach { tip ->
                    Text(
                        text = "• $tip",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 3.dp)
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GlowButton(
                    text = "Abrir armazenamento do Android",
                    onClick = { open(SettingsTarget.STORAGE) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.Storage
                )
                GlowButton(
                    text = "Abrir lista de apps",
                    onClick = { open(SettingsTarget.APPS) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.DeleteSweep,
                    filled = false
                )
            }
        }

        item {
            NeonCard {
                SectionTitle("Garantias do Turbo X")
                Text(
                    text = "O Turbo X não apaga nenhum arquivo seu e não limpa o cache nem os dados de outros apps. " +
                        "A limpeza é feita por você, nas telas oficiais do Android, onde o sistema pede a sua confirmação.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
