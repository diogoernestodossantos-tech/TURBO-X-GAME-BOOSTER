package com.turbox.gamebooster.repository

import com.turbox.gamebooster.model.InstalledApp
import com.turbox.gamebooster.model.LaunchResult
import com.turbox.gamebooster.service.GameScanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class GameRepository(private val scanner: GameScanner) {

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())

    /** Apps com tela inicial visíveis ao Turbo X (cache da última leitura). */
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps.asStateFlow()

    private val refreshLock = Mutex()

    suspend fun refresh(): Result<Unit> = refreshLock.withLock {
        runCatching {
            val apps = scanner.scan()
            _installedApps.value = apps
            Unit
        }
    }

    fun launch(packageName: String): LaunchResult = scanner.launch(packageName)
}
