package com.turbox.gamebooster.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.OptimizationProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

internal val Context.turboDataStore: DataStore<Preferences> by preferencesDataStore(name = "turbox_settings")

/** Preferências e biblioteca do usuário, persistidas com DataStore (somente no aparelho). */
class SettingsRepository(private val dataStore: DataStore<Preferences>) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val PROFILE = stringPreferencesKey("active_profile")
        val INTERVAL = intPreferencesKey("monitor_interval_seconds")
        val TEMP_WARN = intPreferencesKey("temp_warn_celsius")
        val RAM_WARN = intPreferencesKey("ram_warn_percent")
        val FAVORITES = stringSetPreferencesKey("favorite_games")
        val CUSTOM_GAMES = stringSetPreferencesKey("custom_games")
        val RECENTS = stringPreferencesKey("recent_games")
    }

    val settings: Flow<AppSettings> = dataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            AppSettings(
                darkTheme = prefs[Keys.DARK_THEME] ?: AppSettings.DEFAULT_DARK_THEME,
                activeProfile = OptimizationProfile.fromId(prefs[Keys.PROFILE]),
                monitorIntervalSeconds = (prefs[Keys.INTERVAL] ?: AppSettings.DEFAULT_INTERVAL_SECONDS).coerceIn(1, 60),
                tempWarnCelsius = (prefs[Keys.TEMP_WARN] ?: AppSettings.DEFAULT_TEMP_WARN).coerceIn(30, 60),
                ramWarnPercent = (prefs[Keys.RAM_WARN] ?: AppSettings.DEFAULT_RAM_WARN).coerceIn(50, 99),
                favorites = prefs[Keys.FAVORITES] ?: emptySet(),
                customGames = prefs[Keys.CUSTOM_GAMES] ?: emptySet(),
                recentGames = (prefs[Keys.RECENTS] ?: "").split(",").filter { it.isNotBlank() }
            )
        }

    suspend fun setDarkTheme(enabled: Boolean) {
        dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setProfile(profile: OptimizationProfile) {
        dataStore.edit { it[Keys.PROFILE] = profile.id }
    }

    suspend fun setMonitorInterval(seconds: Int) {
        dataStore.edit { it[Keys.INTERVAL] = seconds }
    }

    suspend fun setTempWarn(celsius: Int) {
        dataStore.edit { it[Keys.TEMP_WARN] = celsius }
    }

    suspend fun setRamWarn(percent: Int) {
        dataStore.edit { it[Keys.RAM_WARN] = percent }
    }

    suspend fun toggleFavorite(packageName: String) {
        dataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITES] ?: emptySet()
            prefs[Keys.FAVORITES] = if (packageName in current) current - packageName else current + packageName
        }
    }

    suspend fun addCustomGame(packageName: String) {
        dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_GAMES] = (prefs[Keys.CUSTOM_GAMES] ?: emptySet()) + packageName
        }
    }

    suspend fun removeCustomGame(packageName: String) {
        dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_GAMES] = (prefs[Keys.CUSTOM_GAMES] ?: emptySet()) - packageName
        }
    }

    suspend fun pushRecentGame(packageName: String) {
        dataStore.edit { prefs ->
            val current = (prefs[Keys.RECENTS] ?: "").split(",").filter { it.isNotBlank() }
            val updated = (listOf(packageName) + current.filter { it != packageName }).take(AppSettings.MAX_RECENTS)
            prefs[Keys.RECENTS] = updated.joinToString(",")
        }
    }

    /** Volta tema, perfil, intervalo e limites ao padrão. Não apaga favoritos nem jogos adicionados. */
    suspend fun resetPreferences() {
        dataStore.edit { prefs ->
            prefs.remove(Keys.DARK_THEME)
            prefs.remove(Keys.PROFILE)
            prefs.remove(Keys.INTERVAL)
            prefs.remove(Keys.TEMP_WARN)
            prefs.remove(Keys.RAM_WARN)
        }
    }

    /** Apaga favoritos, jogos adicionados manualmente e jogos recentes. */
    suspend fun resetLibrary() {
        dataStore.edit { prefs ->
            prefs.remove(Keys.FAVORITES)
            prefs.remove(Keys.CUSTOM_GAMES)
            prefs.remove(Keys.RECENTS)
        }
    }
}
