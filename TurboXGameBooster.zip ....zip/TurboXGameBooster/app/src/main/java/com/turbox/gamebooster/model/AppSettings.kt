package com.turbox.gamebooster.model

data class AppSettings(
    val darkTheme: Boolean = DEFAULT_DARK_THEME,
    val activeProfile: OptimizationProfile = OptimizationProfile.BALANCED,
    val monitorIntervalSeconds: Int = DEFAULT_INTERVAL_SECONDS,
    val tempWarnCelsius: Int = DEFAULT_TEMP_WARN,
    val ramWarnPercent: Int = DEFAULT_RAM_WARN,
    val favorites: Set<String> = emptySet(),
    val customGames: Set<String> = emptySet(),
    /** Mais recente primeiro. */
    val recentGames: List<String> = emptyList()
) {
    /** Limite de alerta de temperatura já ajustado pelo perfil ativo. */
    val effectiveTempWarnCelsius: Int get() = tempWarnCelsius + activeProfile.tempWarnDelta

    /** Limite de alerta de RAM já ajustado pelo perfil ativo. */
    val effectiveRamWarnPercent: Int get() = (ramWarnPercent + activeProfile.ramWarnDelta).coerceIn(50, 99)

    companion object {
        const val DEFAULT_DARK_THEME = true
        const val DEFAULT_INTERVAL_SECONDS = 3
        const val DEFAULT_TEMP_WARN = 42
        const val DEFAULT_RAM_WARN = 85
        const val MAX_RECENTS = 8

        val INTERVAL_OPTIONS = listOf(2, 3, 5, 10)
        val TEMP_OPTIONS = listOf(40, 42, 45)
        val RAM_OPTIONS = listOf(80, 85, 90)
    }
}
