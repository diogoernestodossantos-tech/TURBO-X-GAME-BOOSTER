package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

class SettingsViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    /** Null enquanto as preferências ainda estão sendo carregadas. */
    val settings: StateFlow<AppSettings?> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun setDarkTheme(enabled: Boolean) = save { settingsRepository.setDarkTheme(enabled) }

    fun setMonitorInterval(seconds: Int) = save { settingsRepository.setMonitorInterval(seconds) }

    fun setTempWarn(celsius: Int) = save { settingsRepository.setTempWarn(celsius) }

    fun setRamWarn(percent: Int) = save { settingsRepository.setRamWarn(percent) }

    fun resetPreferences() = save("Configurações redefinidas para o padrão.") { settingsRepository.resetPreferences() }

    fun resetLibrary() = save("Favoritos, jogos adicionados e recentes foram apagados.") { settingsRepository.resetLibrary() }

    fun consumeMessage() {
        _message.value = null
    }

    private fun save(successMessage: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                if (successMessage != null) _message.value = successMessage
            } catch (e: IOException) {
                _message.value = "Não foi possível salvar: ${e.message ?: "erro ao gravar"}"
            }
        }
    }
}
