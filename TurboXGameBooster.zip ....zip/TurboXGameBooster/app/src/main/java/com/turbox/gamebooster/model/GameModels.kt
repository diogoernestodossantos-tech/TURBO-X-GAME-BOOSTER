package com.turbox.gamebooster.model

/** App com tela inicial visível ao Turbo X. [declaredGame] = o app se declara como jogo no Android. */
data class InstalledApp(
    val packageName: String,
    val label: String,
    val declaredGame: Boolean
)

/** Item da biblioteca "Meus Jogos". */
data class GameItem(
    val app: InstalledApp,
    val isFavorite: Boolean,
    /** Adicionado manualmente pelo usuário (o app não se declara como jogo). */
    val isCustom: Boolean
)

sealed interface LaunchResult {
    data object Success : LaunchResult
    data object NotLaunchable : LaunchResult
    data class Failed(val reason: String) : LaunchResult
}
