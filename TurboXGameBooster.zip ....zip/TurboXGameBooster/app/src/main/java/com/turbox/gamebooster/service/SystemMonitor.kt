package com.turbox.gamebooster.service

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.view.Display
import com.turbox.gamebooster.model.BatteryInfo
import com.turbox.gamebooster.model.ChargingState
import com.turbox.gamebooster.model.DeviceInfo
import com.turbox.gamebooster.model.DeviceSnapshot
import com.turbox.gamebooster.model.DisplayInfo
import com.turbox.gamebooster.model.PowerSource
import com.turbox.gamebooster.model.RamInfo
import com.turbox.gamebooster.model.StorageInfo
import com.turbox.gamebooster.model.ThermalLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlin.math.roundToInt

/**
 * Leituras do sistema usando somente APIs oficiais e sem permissões especiais:
 * ActivityManager, BatteryManager (broadcast sticky), PowerManager, StatFs e DisplayManager.
 */
class SystemMonitor(context: Context) {

    private val appContext = context.applicationContext
    private val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager

    /**
     * Emite uma leitura a cada [intervalMillis] enquanto houver coletor ativo.
     * O ciclo para sozinho quando a tela deixa de observar (ver SharingStarted.WhileSubscribed nos ViewModels).
     */
    fun snapshots(intervalMillis: Long): Flow<DeviceSnapshot> = flow {
        while (true) {
            emit(readSnapshot())
            delay(intervalMillis)
        }
    }.flowOn(Dispatchers.Default)

    fun readSnapshot(): DeviceSnapshot = DeviceSnapshot(
        ram = readRam(),
        battery = readBattery(),
        thermal = readThermal(),
        powerSaveMode = powerManager.isPowerSaveMode,
        storage = readStorage(),
        display = readDisplay(),
        timestampMillis = System.currentTimeMillis()
    )

    fun readRam(): RamInfo {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return RamInfo(
            totalBytes = info.totalMem,
            availableBytes = info.availMem,
            lowMemory = info.lowMemory,
            lowMemoryThresholdBytes = info.threshold
        )
    }

    fun readBattery(): BatteryInfo {
        // registerReceiver(null, filtro) apenas lê o último valor do broadcast sticky: não registra receiver.
        val intent: Intent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryInfo(null, null, ChargingState.UNKNOWN, PowerSource.UNKNOWN, "Desconhecida")

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt() else null

        // EXTRA_TEMPERATURE vem em décimos de °C. Valores <= 0 são tratados como "não informado".
        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperature = if (tempTenths == Int.MIN_VALUE || tempTenths <= 0) null else tempTenths / 10f

        val charging = when (intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> ChargingState.CHARGING
            BatteryManager.BATTERY_STATUS_DISCHARGING -> ChargingState.DISCHARGING
            BatteryManager.BATTERY_STATUS_FULL -> ChargingState.FULL
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ChargingState.NOT_CHARGING
            else -> ChargingState.UNKNOWN
        }

        val source = when (intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            0 -> PowerSource.NONE
            BatteryManager.BATTERY_PLUGGED_AC -> PowerSource.AC
            BatteryManager.BATTERY_PLUGGED_USB -> PowerSource.USB
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> PowerSource.WIRELESS
            else -> PowerSource.UNKNOWN
        }

        val health = when (intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Boa"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Superaquecida"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Comprometida"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobretensão"
            BatteryManager.BATTERY_HEALTH_COLD -> "Fria"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Falha não especificada"
            else -> "Desconhecida"
        }

        return BatteryInfo(percent, temperature, charging, source, health)
    }

    /** Estado térmico geral do sistema (Android 10+). Não é a temperatura da CPU/GPU. */
    fun readThermal(): ThermalLevel? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return when (powerManager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NONE
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.CRITICAL
            PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalLevel.EMERGENCY
            PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.SHUTDOWN
            else -> null
        }
    }

    /** Armazenamento interno (partição de dados). */
    fun readStorage(): StorageInfo? = runCatching {
        val stat = StatFs(Environment.getDataDirectory().path)
        StorageInfo(totalBytes = stat.totalBytes, freeBytes = stat.availableBytes)
    }.getOrNull()

    fun readDisplay(): DisplayInfo? = runCatching {
        val displayManager = appContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY) ?: return@runCatching null
        val rates = display.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        DisplayInfo(currentRefreshRateHz = display.refreshRate, supportedRefreshRatesHz = rates)
    }.getOrNull()

    /**
     * true se algum modo Não perturbe está ativo; null se o sistema não informar.
     * A leitura do filtro de interrupção não exige permissão (alterá-lo exigiria).
     */
    fun isDoNotDisturbActive(): Boolean? = runCatching {
        val manager = appContext.getSystemService(NotificationManager::class.java)
        when (manager.currentInterruptionFilter) {
            NotificationManager.INTERRUPTION_FILTER_UNKNOWN -> null
            NotificationManager.INTERRUPTION_FILTER_ALL -> false
            else -> true
        }
    }.getOrNull()

    fun readDeviceInfo(): DeviceInfo = DeviceInfo(
        manufacturer = Build.MANUFACTURER.replaceFirstChar { it.titlecase() },
        model = Build.MODEL,
        androidRelease = Build.VERSION.RELEASE,
        sdkInt = Build.VERSION.SDK_INT,
        securityPatch = Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() },
        supportedAbis = Build.SUPPORTED_ABIS.joinToString(", "),
        cpuCores = Runtime.getRuntime().availableProcessors()
    )
}
