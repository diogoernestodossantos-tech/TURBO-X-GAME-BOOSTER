package com.turbox.gamebooster.util

import java.util.Locale

private const val KIB = 1024.0

/** Converte bytes em texto legível. 1 GB aqui = 1024 MB (padrão usado pelo Android). */
fun formatBytes(bytes: Long): String {
    val gb = bytes / (KIB * KIB * KIB)
    return if (gb >= 1.0) {
        String.format(Locale.getDefault(), "%.1f GB", gb)
    } else {
        String.format(Locale.getDefault(), "%.0f MB", bytes / (KIB * KIB))
    }
}

fun formatPercent(fraction: Float): String =
    String.format(Locale.getDefault(), "%.0f%%", fraction * 100f)

fun formatTemperature(celsius: Float?): String =
    if (celsius == null) "Indisponível" else String.format(Locale.getDefault(), "%.1f °C", celsius)
