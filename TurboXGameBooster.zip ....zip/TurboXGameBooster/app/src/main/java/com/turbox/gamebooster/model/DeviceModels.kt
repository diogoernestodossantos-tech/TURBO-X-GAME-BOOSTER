package com.turbox.gamebooster.model

/**
 * Memória RAM lida de ActivityManager.getMemoryInfo().
 * "Em uso" = (total - disponível) / total. Veja a explicação na tela de Monitoramento.
 */
data class RamInfo(
    val totalBytes: Long,
    val availableBytes: Long,
    val lowMemory: Boolean,
    val lowMemoryThresholdBytes: Long
) {
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0L)
    val usedFraction: Float
        get() = if (totalBytes > 0L) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

enum class ChargingState(val label: String) {
    CHARGING("Carregando"),
    DISCHARGING("Descarregando"),
    FULL("Carga completa"),
    NOT_CHARGING("Conectado, sem carregar"),
    UNKNOWN("Desconhecido")
}

enum class PowerSource(val label: String) {
    AC("Tomada (AC)"),
    USB("USB"),
    WIRELESS("Sem fio"),
    NONE("Bateria"),
    UNKNOWN("Desconhecida")
}

data class BatteryInfo(
    val levelPercent: Int?,
    /** Em °C. Null quando o aparelho não informa. */
    val temperatureCelsius: Float?,
    val chargingState: ChargingState,
    val powerSource: PowerSource,
    val healthLabel: String
)

/** Estado térmico geral do sistema (PowerManager.getCurrentThermalStatus, Android 10+). */
enum class ThermalLevel(val label: String, val severity: Int) {
    NONE("Normal", 0),
    LIGHT("Leve", 1),
    MODERATE("Moderado", 2),
    SEVERE("Severo", 3),
    CRITICAL("Crítico", 4),
    EMERGENCY("Emergência", 5),
    SHUTDOWN("Desligamento iminente", 6)
}

data class DisplayInfo(
    val currentRefreshRateHz: Float,
    val supportedRefreshRatesHz: List<Int>
)

data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long
) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0L)
    val freeFraction: Float
        get() = if (totalBytes > 0L) (freeBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
    val usedFraction: Float get() = 1f - freeFraction
}

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String?,
    val supportedAbis: String,
    val cpuCores: Int
)

/** Leitura instantânea de tudo que o app monitora. */
data class DeviceSnapshot(
    val ram: RamInfo,
    val battery: BatteryInfo,
    /** Null em aparelhos com Android 9 ou anterior. */
    val thermal: ThermalLevel?,
    val powerSaveMode: Boolean,
    val storage: StorageInfo?,
    val display: DisplayInfo?,
    val timestampMillis: Long
)
