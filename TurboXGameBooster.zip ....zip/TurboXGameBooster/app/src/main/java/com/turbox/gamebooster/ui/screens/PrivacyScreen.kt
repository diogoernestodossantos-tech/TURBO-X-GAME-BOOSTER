package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader

private val sections = listOf(
    "Resumo" to "O Turbo X Game Booster funciona totalmente no seu aparelho. Ele não tem acesso à internet, " +
        "não cria conta, não usa anúncios e não envia nenhuma informação para fora do aparelho.",
    "O que o app lê" to "Memória RAM, bateria (nível, temperatura, estado de carga), estado térmico geral, armazenamento " +
        "interno, taxa de atualização da tela e dados básicos do aparelho (fabricante, modelo, versão do Android). " +
        "Essas leituras são feitas por APIs oficiais do Android, são exibidas na tela e não são gravadas.",
    "Lista de apps" to "Para montar a biblioteca de jogos, o app consulta quais apps com tela inicial estão visíveis a ele " +
        "e seus nomes e ícones. Essa lista é usada só na tela e não sai do aparelho. O app não usa a permissão " +
        "QUERY_ALL_PACKAGES.",
    "O que fica salvo" to "Apenas as suas preferências, guardadas localmente no aparelho: tema, perfil ativo, intervalo e " +
        "limites de alerta, favoritos, jogos adicionados por você e a lista de jogos abertos recentemente. " +
        "Você pode apagar tudo em Configurações > Redefinir, ou desinstalando o app.",
    "Permissões" to "O app não solicita nenhuma permissão. Ele não acessa fotos, arquivos, contatos, microfone, câmera nem localização.",
    "Armazenamento e outros apps" to "O app não apaga arquivos seus nem dados ou cache de outros apps. Para liberar espaço, ele apenas abre " +
        "as telas oficiais de configurações do Android, onde você decide o que fazer.",
    "Limites do app" to "O app não usa root nem ADB e não altera CPU, GPU, memória ou FPS. Ele não promete aumento de FPS: " +
        "oferece diagnóstico real e recomendações que você aplica por conta própria.",
    "Contato" to "Antes de publicar o app em uma loja, inclua aqui o contato do responsável pelo tratamento de dados e a data " +
        "de vigência desta política."
)

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader(title = "Privacidade", subtitle = "Política de privacidade", onBack = onBack) }
        items(sections.size) { index ->
            val (title, body) = sections[index]
            NeonCard {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
