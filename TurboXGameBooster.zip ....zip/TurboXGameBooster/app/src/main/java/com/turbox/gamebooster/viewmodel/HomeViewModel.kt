package com.turbox.gamebooster.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.DeviceInfo
import com.turbox.gamebooster.model.DeviceSnapshot
import com.turbox.gamebooster.model.InstalledApp
import com.turbox.gamebooster.model.LaunchResult
import com.turbox.gamebooster.model.TurboState
import com.turbox.gamebooster.model.TurboStep
import com.turbox.gamebooster.repository.DeviceRepository
import com.turbox.gamebooster.repository.GameRepository
import com.turbox.gamebooster.repository.SettingsRepository
import com.turbox.gamebooster.service.TurboModeRunner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val snapshot: DeviceSnapshot? = null,
    val deviceInfo: DeviceInfo,
    val settings: AppSettings = AppSettings(),
    val recentGames: List<InstalledApp> = emptyList(),
    val turbo: TurboState = TurboState.Idle,
    val message: String? = null
)

class HomeViewModel(
    private val deviceRepository: DeviceRepository,
    private val gameRepository: GameRepository,
    private val settingsRepository: SettingsRepository,
    private val turboModeRunner: TurboModeRunner
) : ViewModel() {

    private val turbo = MutableStateFlow<TurboState>(TurboState.Idle)
    private val message = MutableStateFlow<String?>(null)
    private var turboJob: Job? = null

    private val deviceInfo = deviceRepository.deviceInfo()

    private val snapshot: StateFlow<DeviceSnapshot?> = deviceRepository.liveSnapshots()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val uiState: StateFlow<HomeUiState> = combine(
        snapshot,
        settingsRepository.settings,
        gameRepository.installedApps,
        turbo,
        message
    ) { snap, settings, apps, turboState, msg ->
        HomeUiState(
            snapshot = snap,
            deviceInfo = deviceInfo,
            settings = settings,
            recentGames = settings.recentGames.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } },
            turbo = turboState,
            message = msg
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState(deviceInfo = deviceInfo))

    init {
        viewModelScope.launch { gameRepository.refresh() }
    }

    fun runTurbo() {
        if (turbo.value is TurboState.Running) return
        turboJob = viewModelScope.launch {
            val collected = mutableListOf<TurboStep>()
            turbo.value = TurboState.Running(emptyList())
            try {
                val settings = settingsRepository.settings.first()
                turboModeRunner.run(settings).collect { step ->
                    collected += step
                    turbo.value = TurboState.Running(collected.toList())
                }
                turbo.value = TurboState.Done(collected.toList())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                turbo.value = TurboState.Failed(
                    "O diagnóstico foi interrompido: ${e.message ?: "erro desconhecido"}",
                    collected.toList()
                )
            }
        }
    }

    fun dismissTurbo() {
        turboJob?.cancel()
        turbo.value = TurboState.Idle
    }

    fun launchGame(packageName: String) {
        when (val result = gameRepository.launch(packageName)) {
            LaunchResult.Success -> viewModelScope.launch { settingsRepository.pushRecentGame(packageName) }
            LaunchResult.NotLaunchable -> message.update {
                "Não foi possível abrir este jogo: ele não tem tela inicial ou foi desinstalado."
            }
            is LaunchResult.Failed -> message.update { "Não foi possível abrir o jogo: ${result.reason}" }
        }
    }

    fun consumeMessage() {
        message.value = null
    }
}
