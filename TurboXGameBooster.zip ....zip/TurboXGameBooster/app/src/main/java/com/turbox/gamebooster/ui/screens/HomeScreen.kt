package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.model.SettingsTarget
import com.turbox.gamebooster.model.StepStatus
import com.turbox.gamebooster.model.TurboState
import com.turbox.gamebooster.model.TurboStep
import com.turbox.gamebooster.ui.common.LocalSnackbar
import com.turbox.gamebooster.ui.common.batteryLevelColor
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.temperatureColor
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.common.usageColor
import com.turbox.gamebooster.ui.components.AppIcon
import com.turbox.gamebooster.ui.components.MetricGauge
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.SectionTitle
import com.turbox.gamebooster.ui.components.StatusChip
import com.turbox.gamebooster.ui.components.TurboLogo
import com.turbox.gamebooster.ui.components.TurboPowerButton
import com.turbox.gamebooster.ui.navigation.Routes
import com.turbox.gamebooster.ui.theme.TurboAmber
import com.turbox.gamebooster.ui.theme.TurboGreen
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.util.SystemSettings
import com.turbox.gamebooster.util.formatBytes
import com.turbox.gamebooster.util.formatPercent
import com.turbox.gamebooster.viewmodel.HomeUiState
import com.turbox.gamebooster.viewmodel.HomeViewModel
import java.util.Calendar
import java.util.Locale

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val viewModel: HomeViewModel = turboViewModel()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = LocalSnackbar.current
    val context = LocalContext.current

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { HomeHeader() }
        item { DeviceStatusCard(state) }
        item {
            TurboSection(
                turbo = state.turbo,
                onRun = viewModel::runTurbo,
                onClear = viewModel::dismissTurbo,
                onOpenSettings = { SystemSettings.open(context, it) }
            )
        }
        item {
            RecentGamesSection(
                games = state.recentGames,
                onLaunch = viewModel::launchGame,
                onOpenLibrary = { onOpen(Routes.GAMES) }
            )
        }
        item { ShortcutsSection(onOpen) }
    }
}

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 5 -> "Boa madrugada"
        hour < 12 -> "Bom dia"
        hour < 18 -> "Boa tarde"
        else -> "Boa noite"
    }
}

@Composable
private fun HomeHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TurboLogo()
        Text(
            text = "${greeting()}, jogador!",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = "Veja como está o seu aparelho e rode o diagnóstico antes de jogar.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun DeviceStatusCard(state: HomeUiState) {
    val snapshot = state.snapshot
    val info = state.deviceInfo
    NeonCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Smartphone, contentDescription = null, tint = TurboRed)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = "${info.manufacturer} ${info.model}",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Android ${info.androidRelease} · API ${info.sdkInt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        if (snapshot == null) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = TurboRed)
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Lendo dados do aparelho…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@NeonCard
        }

        val tempLimit = state.settings.effectiveTempWarnCelsius
        val ramLimit = state.settings.effectiveRamWarnPercent
        val level = snapshot.battery.levelPercent
        val temp = snapshot.battery.temperatureCelsius

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            MetricGauge(
                fraction = snapshot.ram.usedFraction,
                valueText = formatPercent(snapshot.ram.usedFraction),
                label = "RAM em uso",
                color = usageColor(snapshot.ram.usedFraction, ramLimit)
            )
            MetricGauge(
                fraction = level?.let { it / 100f },
                valueText = level?.let { "$it%" } ?: "—",
                label = "Bateria",
                color = batteryLevelColor(level)
            )
            MetricGauge(
                fraction = temp?.let { it / 60f },
                valueText = temp?.let { String.format(Locale.getDefault(), "%.0f°C", it) } ?: "—",
                label = "Temp. bateria",
                color = temperatureColor(temp, tempLimit)
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(
            text = "${formatBytes(snapshot.ram.availableBytes)} de RAM disponíveis (de ${formatBytes(snapshot.ram.totalBytes)})",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip(snapshot.battery.chargingState.label, TurboGreen)
            if (temp == null) StatusChip("Temperatura não informada", TurboAmber)
        }
    }
}

@Composable
private fun TurboSection(
    turbo: TurboState,
    onRun: () -> Unit,
    onClear: () -> Unit,
    onOpenSettings: (SettingsTarget) -> Unit
) {
    NeonCard(glow = true) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            TurboPowerButton(running = turbo is TurboState.Running, onClick = onRun)
        }
        Text(
            text = "Executa verificações reais de memória, bateria, temperatura, energia e armazenamento " +
                "e mostra o que foi encontrado. Não altera CPU nem GPU.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        when (turbo) {
            TurboState.Idle -> Unit
            is TurboState.Running -> {
                Spacer(Modifier.height(14.dp))
                turbo.steps.forEach { StepRow(it, onOpenSettings) }
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = TurboRed)
            }
            is TurboState.Done -> {
                Spacer(Modifier.height(14.dp))
                val attention = turbo.steps.count { it.status == StepStatus.ATTENTION }
                val ok = turbo.steps.count { it.status == StepStatus.OK }
                Text(
                    text = if (attention == 0) {
                        "Diagnóstico concluído: $ok verificações OK e nenhum ponto de atenção."
                    } else {
                        "Diagnóstico concluído: $ok OK e $attention ponto(s) de atenção."
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = if (attention == 0) TurboGreen else TurboAmber
                )
                Spacer(Modifier.height(8.dp))
                turbo.steps.forEach { StepRow(it, onOpenSettings) }
                TextButton(onClick = onClear, modifier = Modifier.align(Alignment.End)) { Text("Limpar relatório") }
            }
            is TurboState.Failed -> {
                Spacer(Modifier.height(14.dp))
                Text(turbo.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                turbo.steps.forEach { StepRow(it, onOpenSettings) }
                TextButton(onClick = onClear, modifier = Modifier.align(Alignment.End)) { Text("Fechar") }
            }
        }
    }
}

@Composable
private fun StepRow(step: TurboStep, onOpenSettings: (SettingsTarget) -> Unit) {
    val (icon, tint) = when (step.status) {
        StepStatus.OK -> Icons.Filled.CheckCircle to TurboGreen
        StepStatus.ATTENTION -> Icons.Filled.Warning to TurboAmber
        StepStatus.INFO -> Icons.Filled.Info to MaterialTheme.colorScheme.onSurfaceVariant
        StepStatus.UNAVAILABLE -> Icons.Filled.Block to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(step.title, style = MaterialTheme.typography.titleMedium)
            Text(
                step.detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (step.status == StepStatus.ATTENTION && step.hint != null) {
                Text(step.hint, style = MaterialTheme.typography.bodySmall, color = TurboAmber)
            }
            val action = step.action
            if (action != null) {
                TextButton(onClick = { onOpenSettings(action) }) {
                    Text("Abrir ${action.label}", color = TurboRed)
                }
            }
        }
    }
}

@Composable
private fun RecentGamesSection(
    games: List<com.turbox.gamebooster.model.InstalledApp>,
    onLaunch: (String) -> Unit,
    onOpenLibrary: () -> Unit
) {
    NeonCard {
        SectionTitle("Jogos recentes")
        if (games.isEmpty()) {
            Text(
                text = "Nenhum jogo aberto pelo Turbo X ainda. Abra um jogo pela sua biblioteca e ele aparece aqui.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = onOpenLibrary) { Text("Ir para Meus Jogos", color = TurboRed) }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(games, key = { it.packageName }) { app ->
                    Column(
                        modifier = Modifier.width(76.dp).clickable { onLaunch(app.packageName) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AppIcon(app.packageName, 54.dp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

private data class Shortcut(val title: String, val subtitle: String, val icon: ImageVector, val route: String)

@Composable
private fun ShortcutsSection(onOpen: (String) -> Unit) {
    val shortcuts = listOf(
        Shortcut("Meus Jogos", "Biblioteca e favoritos", Icons.Filled.SportsEsports, Routes.GAMES),
        Shortcut("Otimização", "Perfis de jogo", Icons.Filled.Speed, Routes.OPTIMIZATION),
        Shortcut("Monitoramento", "RAM, bateria e mais", Icons.Filled.MonitorHeart, Routes.MONITOR),
        Shortcut("Armazenamento", "Liberar espaço", Icons.Filled.DeleteSweep, Routes.STORAGE),
        Shortcut("FPS Monitor", "O que é possível medir", Icons.Filled.Timeline, Routes.FPS)
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("Atalhos")
        shortcuts.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { shortcut ->
                    NeonCard(modifier = Modifier.weight(1f), onClick = { onOpen(shortcut.route) }) {
                        Icon(shortcut.icon, contentDescription = null, tint = TurboRed)
                        Spacer(Modifier.height(8.dp))
                        Text(shortcut.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            shortcut.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
