package com.turbox.gamebooster.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.turbox.gamebooster.model.SettingsTarget

/** Abre telas oficiais de configurações do Android. O usuário aplica o ajuste; o app não altera nada sozinho. */
object SystemSettings {

    private fun actionFor(target: SettingsTarget): String = when (target) {
        SettingsTarget.DISPLAY -> Settings.ACTION_DISPLAY_SETTINGS
        SettingsTarget.BATTERY_SAVER -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        SettingsTarget.STORAGE -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
        SettingsTarget.SOUND_DND -> Settings.ACTION_SOUND_SETTINGS
        SettingsTarget.WIFI -> Settings.ACTION_WIFI_SETTINGS
        SettingsTarget.APPS -> Settings.ACTION_APPLICATION_SETTINGS
        SettingsTarget.DEVELOPER -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
    }

    /**
     * Tenta abrir a tela específica; se o fabricante não a oferecer, abre as configurações gerais.
     * Retorna false se nada pôde ser aberto.
     */
    fun open(context: Context, target: SettingsTarget): Boolean {
        for (action in listOf(actionFor(target), Settings.ACTION_SETTINGS)) {
            try {
                context.startActivity(Intent(action))
                return true
            } catch (_: ActivityNotFoundException) {
                // tenta a próxima opção
            } catch (_: SecurityException) {
                // tenta a próxima opção
            }
        }
        return false
    }
}
