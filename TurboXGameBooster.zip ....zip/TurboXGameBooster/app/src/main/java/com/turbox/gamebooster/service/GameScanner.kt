package com.turbox.gamebooster.service

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import com.turbox.gamebooster.model.InstalledApp
import com.turbox.gamebooster.model.LaunchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lê os apps visíveis ao Turbo X e abre jogos pelo pacote.
 *
 * Visibilidade: usamos apenas a consulta <queries> do Manifest (apps com tela inicial).
 * Não usamos QUERY_ALL_PACKAGES.
 */
class GameScanner(context: Context) {

    private val appContext = context.applicationContext

    /** Todos os apps com tela inicial visíveis ao app (exceto o próprio Turbo X), ordenados por nome. */
    suspend fun scan(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = appContext.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

        queryLaunchable(pm, query)
            .asSequence()
            .mapNotNull { info ->
                val appInfo = info.activityInfo?.applicationInfo ?: return@mapNotNull null
                if (appInfo.packageName == appContext.packageName) {
                    null
                } else {
                    InstalledApp(
                        packageName = appInfo.packageName,
                        label = info.loadLabel(pm).toString(),
                        declaredGame = appInfo.declaresGame()
                    )
                }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** Abre o jogo pela intent de lançamento do pacote. */
    fun launch(packageName: String): LaunchResult {
        val intent = appContext.packageManager.getLaunchIntentForPackage(packageName)
            ?: return LaunchResult.NotLaunchable
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            appContext.startActivity(intent)
            LaunchResult.Success
        } catch (e: Exception) {
            LaunchResult.Failed(e.message ?: "erro desconhecido")
        }
    }

    @Suppress("DEPRECATION")
    private fun queryLaunchable(pm: PackageManager, intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            pm.queryIntentActivities(intent, 0)
        }

    /** Jogo = categoria GAME (Android 8+) ou o antigo flag FLAG_IS_GAME. */
    @Suppress("DEPRECATION")
    private fun ApplicationInfo.declaresGame(): Boolean =
        category == ApplicationInfo.CATEGORY_GAME || (flags and ApplicationInfo.FLAG_IS_GAME) != 0
}
