package com.turbox.gamebooster.ui.theme

import androidx.compose.ui.graphics.Color

val TurboBackground = Color(0xFF080808)
val TurboCard = Color(0xFF151515)
val TurboRed = Color(0xFFFF2020)
val TurboRedDark = Color(0xFFB00020)
val TurboTextPrimary = Color(0xFFFFFFFF)
val TurboTextSecondary = Color(0xFFA0A0A0)
val TurboGreen = Color(0xFF20D977)

/** Cor de "ponto de atenção" (não faz parte da paleta base; usada só para avisos). */
val TurboAmber = Color(0xFFFFB020)
