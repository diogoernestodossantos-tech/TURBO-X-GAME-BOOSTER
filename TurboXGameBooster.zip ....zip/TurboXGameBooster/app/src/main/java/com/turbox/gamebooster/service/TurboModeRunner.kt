package com.turbox.gamebooster.service

import android.os.Build
import com.turbox.gamebooster.model.AppSettings
import com.turbox.gamebooster.model.BatteryInfo
import com.turbox.gamebooster.model.ChargingState
import com.turbox.gamebooster.model.DisplayInfo
import com.turbox.gamebooster.model.OptimizationProfile
import com.turbox.gamebooster.model.RamInfo
import com.turbox.gamebooster.model.SettingsTarget
import com.turbox.gamebooster.model.StepStatus
import com.turbox.gamebooster.model.StorageInfo
import com.turbox.gamebooster.model.ThermalLevel
import com.turbox.gamebooster.model.TurboStep
import com.turbox.gamebooster.util.formatBytes
import com.turbox.gamebooster.util.formatPercent
import com.turbox.gamebooster.util.formatTemperature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.yield
import java.util.Locale

/**
 * Turbo Mode = diagnóstico real do aparelho + recomendações.
 *
 * Cada passo lê um dado verdadeiro do sistema (sem números inventados). O Turbo Mode NÃO altera
 * CPU, GPU, RAM nem encerra outros apps: o Android não permite isso a apps comuns sem root.
 * O último passo informa isso ao usuário de forma explícita.
 */
class TurboModeRunner(private val monitor: SystemMonitor) {

    fun run(settings: AppSettings): Flow<TurboStep> = flow {
        val snapshot = monitor.readSnapshot()
        val dnd = monitor.isDoNotDisturbActive()
        val tempLimit = settings.effectiveTempWarnCelsius
        val ramLimit = settings.effectiveRamWarnPercent

        val steps: List<() -> TurboStep> = listOf(
            { profileStep(settings.activeProfile, tempLimit, ramLimit) },
            { memoryStep(snapshot.ram, ramLimit) },
            { batteryLevelStep(snapshot.battery) },
            { batteryTemperatureStep(snapshot.battery, tempLimit) },
            { thermalStep(snapshot.thermal) },
            { powerSaveStep(snapshot.powerSaveMode) },
            { storageStep(snapshot.storage) },
            { dndStep(dnd) },
            { displayStep(snapshot.display) }
        )
        for (build in steps) {
            emit(build())
            yield()
        }
        emit(limitsStep())
    }.flowOn(Dispatchers.Default)

    private fun profileStep(profile: OptimizationProfile, tempLimit: Int, ramLimit: Int) = TurboStep(
        title = "Perfil ativo: ${profile.title}",
        detail = "Limites de alerta desta verificação: bateria $tempLimit °C e RAM $ramLimit%.",
        status = StepStatus.INFO
    )

    private fun memoryStep(ram: RamInfo, ramLimit: Int): TurboStep {
        val usedPercent = ram.usedFraction * 100f
        val detail = "${formatBytes(ram.availableBytes)} disponíveis de ${formatBytes(ram.totalBytes)} " +
            "(${formatPercent(ram.usedFraction)} em uso)."
        return when {
            ram.lowMemory -> TurboStep(
                "Memória RAM", "$detail O sistema sinalizou pouca memória.", StepStatus.ATTENTION,
                hint = "Feche manualmente os apps que você não está usando pela tela de Recentes."
            )
            usedPercent >= ramLimit -> TurboStep(
                "Memória RAM", "$detail Acima do limite de alerta ($ramLimit%).", StepStatus.ATTENTION,
                hint = "Feche manualmente apps em segundo plano antes de abrir o jogo."
            )
            else -> TurboStep("Memória RAM", detail, StepStatus.OK)
        }
    }

    private fun batteryLevelStep(battery: BatteryInfo): TurboStep {
        val level = battery.levelPercent
            ?: return TurboStep("Nível da bateria", "O aparelho não informou o nível.", StepStatus.UNAVAILABLE)
        val detail = "$level% · ${battery.chargingState.label}."
        return if (level < 20 && battery.chargingState != ChargingState.CHARGING) {
            TurboStep(
                "Nível da bateria", detail, StepStatus.ATTENTION,
                hint = "Bateria baixa pode ativar a economia de energia e reduzir o desempenho. Carregue antes de jogar."
            )
        } else {
            TurboStep("Nível da bateria", detail, StepStatus.OK)
        }
    }

    private fun batteryTemperatureStep(battery: BatteryInfo, tempLimit: Int): TurboStep {
        val temp = battery.temperatureCelsius ?: return TurboStep(
            "Temperatura da bateria",
            "Este aparelho não informa a temperatura da bateria.",
            StepStatus.UNAVAILABLE
        )
        return if (temp >= tempLimit) {
            TurboStep(
                "Temperatura da bateria",
                "${formatTemperature(temp)} · acima do limite de alerta ($tempLimit °C).",
                StepStatus.ATTENTION,
                hint = "Faça uma pausa, retire a capa e evite jogar com o carregador conectado."
            )
        } else {
            TurboStep("Temperatura da bateria", "${formatTemperature(temp)} · dentro do limite ($tempLimit °C).", StepStatus.OK)
        }
    }

    private fun thermalStep(level: ThermalLevel?): TurboStep {
        if (level == null) {
            return TurboStep(
                "Estado térmico do sistema",
                "Disponível a partir do Android 10 (este aparelho usa Android ${Build.VERSION.RELEASE}).",
                StepStatus.UNAVAILABLE
            )
        }
        return if (level.severity >= ThermalLevel.MODERATE.severity) {
            TurboStep(
                "Estado térmico do sistema", "${level.label}. O sistema pode reduzir o desempenho para esfriar.",
                StepStatus.ATTENTION,
                hint = "Deixe o aparelho esfriar antes de continuar jogando."
            )
        } else {
            TurboStep("Estado térmico do sistema", "${level.label}.", StepStatus.OK)
        }
    }

    private fun powerSaveStep(active: Boolean): TurboStep = if (active) {
        TurboStep(
            "Economia de bateria", "Ativada.", StepStatus.ATTENTION,
            hint = "A economia de bateria pode limitar o desempenho. Desative enquanto joga.",
            action = SettingsTarget.BATTERY_SAVER
        )
    } else {
        TurboStep("Economia de bateria", "Desativada.", StepStatus.OK)
    }

    private fun storageStep(storage: StorageInfo?): TurboStep {
        if (storage == null) {
            return TurboStep("Armazenamento", "Não foi possível ler o espaço livre.", StepStatus.UNAVAILABLE)
        }
        val detail = "${formatBytes(storage.freeBytes)} livres de ${formatBytes(storage.totalBytes)} " +
            "(${formatPercent(storage.freeFraction)} livre)."
        val low = storage.freeFraction < 0.10f || storage.freeBytes < 2L * 1024 * 1024 * 1024
        return if (low) {
            TurboStep(
                "Armazenamento", detail, StepStatus.ATTENTION,
                hint = "Pouco espaço livre pode causar lentidão e travamentos. Libere espaço.",
                action = SettingsTarget.STORAGE
            )
        } else {
            TurboStep("Armazenamento", detail, StepStatus.OK)
        }
    }

    private fun dndStep(active: Boolean?): TurboStep = when (active) {
        null -> TurboStep("Não perturbe", "O sistema não informou o estado.", StepStatus.UNAVAILABLE)
        true -> TurboStep("Não perturbe", "Ativo: notificações não vão interromper a partida.", StepStatus.OK)
        false -> TurboStep(
            "Não perturbe", "Desativado: notificações podem interromper a partida.", StepStatus.INFO,
            hint = null, action = SettingsTarget.SOUND_DND
        )
    }

    private fun displayStep(display: DisplayInfo?): TurboStep {
        if (display == null) {
            return TurboStep("Taxa de atualização da tela", "Não foi possível ler os dados da tela.", StepStatus.UNAVAILABLE)
        }
        val current = String.format(Locale.getDefault(), "%.0f Hz", display.currentRefreshRateHz)
        val modes = display.supportedRefreshRatesHz.joinToString(", ") { "$it Hz" }
        return TurboStep(
            "Taxa de atualização da tela",
            "Agora: $current · modos suportados: $modes. Isso é a capacidade da tela, não o FPS do jogo.",
            StepStatus.INFO,
            action = SettingsTarget.DISPLAY
        )
    }

    private fun limitsStep() = TurboStep(
        title = "Ajustes automáticos no sistema",
        detail = "Nenhum ajuste foi aplicado. O Android não permite que apps comuns alterem CPU, GPU, memória " +
            "ou encerrem outros apps. As verificações acima são reais e as recomendações são ações que você pode fazer.",
        status = StepStatus.INFO
    )
}
