package com.turbox.gamebooster.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = TurboRed,
    onPrimary = Color.White,
    primaryContainer = TurboRedDark,
    onPrimaryContainer = Color.White,
    secondary = TurboRedDark,
    onSecondary = Color.White,
    background = TurboBackground,
    onBackground = TurboTextPrimary,
    surface = TurboCard,
    onSurface = TurboTextPrimary,
    surfaceVariant = Color(0xFF1E1E1E),
    onSurfaceVariant = TurboTextSecondary,
    outline = Color(0xFF2E2E2E),
    outlineVariant = Color(0xFF242424),
    error = Color(0xFFFF5252),
    onError = Color.White
)

private val LightColors = lightColorScheme(
    primary = TurboRed,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD6),
    onPrimaryContainer = Color(0xFF410002),
    secondary = TurboRedDark,
    onSecondary = Color.White,
    background = Color(0xFFF4F4F4),
    onBackground = Color(0xFF111111),
    surface = Color.White,
    onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFEDEDED),
    onSurfaceVariant = Color(0xFF5A5A5A),
    outline = Color(0xFFD6D6D6),
    outlineVariant = Color(0xFFE4E4E4),
    error = TurboRedDark,
    onError = Color.White
)

@Composable
fun TurboXTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = TurboTypography,
        content = content
    )
}
