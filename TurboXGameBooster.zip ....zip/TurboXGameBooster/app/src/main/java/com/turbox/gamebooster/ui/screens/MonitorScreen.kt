package com.turbox.gamebooster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbox.gamebooster.model.ChargingState
import com.turbox.gamebooster.ui.common.batteryLevelColor
import com.turbox.gamebooster.ui.common.rememberScreenPadding
import com.turbox.gamebooster.ui.common.temperatureColor
import com.turbox.gamebooster.ui.common.turboViewModel
import com.turbox.gamebooster.ui.common.usageColor
import com.turbox.gamebooster.ui.components.InfoRow
import com.turbox.gamebooster.ui.components.MetricGauge
import com.turbox.gamebooster.ui.components.NeonCard
import com.turbox.gamebooster.ui.components.ScreenHeader
import com.turbox.gamebooster.ui.components.SectionTitle
import com.turbox.gamebooster.ui.navigation.Routes
import com.turbox.gamebooster.ui.theme.TurboRed
import com.turbox.gamebooster.util.formatBytes
import com.turbox.gamebooster.util.formatPercent
import com.turbox.gamebooster.util.formatTemperature
import com.turbox.gamebooster.viewmodel.MonitorViewModel
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MonitorScreen(onOpen: (String) -> Unit) {
    val viewModel: MonitorViewModel = turboViewModel()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snapshot = state.snapshot
    val info = state.deviceInfo

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = rememberScreenPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = "Monitoramento",
                subtitle = "Dados reais, atualizados a cada ${state.settings.monitorIntervalSeconds} s"
            )
        }

        if (snapshot == null) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TurboRed)
                }
            }
        } else {
            val ram = snapshot.ram
            val battery = snapshot.battery
            val tempLimit = state.settings.effectiveTempWarnCelsius
            val ramLimit = state.settings.effectiveRamWarnPercent

            item {
                NeonCard {
                    SectionTitle("Memória RAM")
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MetricGauge(
                            fraction = ram.usedFraction,
                            valueText = formatPercent(ram.usedFraction),
                            label = "Em uso",
                            color = usageColor(ram.usedFraction, ramLimit)
                        )
                        Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
                            InfoRow("Total", formatBytes(ram.totalBytes))
                            InfoRow("Disponível", formatBytes(ram.availableBytes))
                            InfoRow("Em uso", formatBytes(ram.usedBytes))
                            InfoRow("Pouca memória?", if (ram.lowMemory) "Sim" else "Não")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Como é calculado: em uso = (total − disponível) ÷ total. Os valores vêm do " +
                            "ActivityManager. \"Disponível\" é a memória que o sistema pode ceder a apps sem " +
                            "encerrar nada importante; o Android mantém o resto ocupado de propósito com cache, " +
                            "então um uso alto é normal e não indica problema por si só.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                NeonCard {
                    SectionTitle("Bateria")
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MetricGauge(
                            fraction = battery.levelPercent?.let { it / 100f },
                            valueText = battery.levelPercent?.let { "$it%" } ?: "—",
                            label = "Nível",
                            color = batteryLevelColor(battery.levelPercent)
                        )
                        Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
                            InfoRow("Estado", battery.chargingState.label)
                            InfoRow("Fonte", battery.powerSource.label)
                            InfoRow("Saúde", battery.healthLabel)
                            InfoRow("Temperatura", formatTemperature(battery.temperatureCelsius))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val tempNote = if (battery.temperatureCelsius == null) {
                        "Este aparelho não informa a temperatura da bateria, então nenhum valor é exibido. "
                    } else {
                        "Alerta do Turbo X a partir de $tempLimit °C (perfil ${state.settings.activeProfile.title}). "
                    }
                    Text(
                        text = tempNote + "É a temperatura da bateria, não da CPU ou GPU.",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (battery.temperatureCelsius != null) {
                            temperatureColor(battery.temperatureCelsius, tempLimit)
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    if (battery.chargingState == ChargingState.CHARGING) {
                        Text(
                            text = "Jogar carregando aquece mais o aparelho.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                NeonCard {
                    SectionTitle("Sistema")
                    InfoRow("Estado térmico", snapshot.thermal?.label ?: "Requer Android 10 ou superior")
                    InfoRow("Economia de bateria", if (snapshot.powerSaveMode) "Ativada" else "Desativada")
                    snapshot.display?.let { display ->
                        InfoRow("Tela agora", String.format(Locale.getDefault(), "%.0f Hz", display.currentRefreshRateHz))
                        InfoRow("Modos da tela", display.supportedRefreshRatesHz.joinToString(", ") { "$it Hz" })
                    }
                    snapshot.storage?.let { storage ->
                        InfoRow("Armazenamento livre", "${formatBytes(storage.freeBytes)} de ${formatBytes(storage.totalBytes)}")
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "CPU e GPU: o Android não expõe a temperatura nem a frequência desses componentes a apps comuns, " +
                            "por isso o Turbo X não exibe esses valores.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                NeonCard {
                    SectionTitle("Aparelho")
                    InfoRow("Fabricante", info.manufacturer)
                    InfoRow("Modelo", info.model)
                    InfoRow("Versão do Android", "${info.androidRelease} (API ${info.sdkInt})")
                    info.securityPatch?.let { InfoRow("Patch de segurança", it) }
                    InfoRow("Arquitetura", info.supportedAbis)
                    InfoRow("Núcleos de CPU", info.cpuCores.toString())
                }
            }

            item {
                Text(
                    text = "Última leitura: " + DateFormat.getTimeInstance().format(Date(snapshot.timestampMillis)) +
                        ". A leitura para quando você sai desta tela, para não gastar bateria.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
