# TURBO X GAME BOOSTER — Etapa 1 (estrutura inicial funcional)

App Android nativo (Kotlin + Jetpack Compose + Material 3) com tema preto e vermelho neon.
Nenhuma permissão é solicitada, não usa root nem ADB e não exibe números inventados.

## Arquitetura

MVVM + Repository, injeção manual (`AppContainer`):

```
UI (Compose) ──► ViewModel ──► Repository ──► Service / DataStore
 screens/        StateFlow     DeviceRepository   SystemMonitor (ActivityManager, BatteryManager,
 components/     por tela      GameRepository                    PowerManager, StatFs, DisplayManager)
 navigation/                   SettingsRepository GameScanner   (PackageManager, <queries>)
 theme/                                           TurboModeRunner (diagnóstico real)
```

```
app/src/main/java/com/turbox/gamebooster/
├── MainActivity.kt, TurboXApp.kt
├── di/AppContainer.kt
├── model/          AppSettings, DeviceModels, GameModels, OptimizationModels, TurboModels
├── repository/     DeviceRepository, GameRepository, SettingsRepository (DataStore)
├── service/        SystemMonitor, GameScanner, TurboModeRunner
├── util/           Format, SystemSettings
├── viewmodel/      Home, Games, Optimization, Monitor, Settings + Factory
└── ui/
    ├── theme/      Color, Type, Theme
    ├── components/ NeonCard, GlowButton, TurboPowerButton, MetricGauge, ...
    ├── navigation/ Routes, TurboNavHost
    └── screens/    Home, Games, Optimization, Monitor, Settings, Storage, FpsMonitor, Privacy
```

## O que é real e o que não é

- **Turbo Mode**: diagnóstico real (RAM, bateria, temperatura da bateria, estado térmico, economia de
  bateria, armazenamento, Não perturbe, taxa de atualização da tela) + recomendações com atalhos para as
  configurações do Android. **Não altera CPU, GPU, RAM nem fecha apps** (o Android não permite). O último
  passo do relatório informa isso ao usuário.
- **Perfis**: mudam os limites de alerta do Turbo Mode e as recomendações exibidas.
- **FPS Monitor**: não existe API para ler o FPS de outros jogos; a tela explica isso e mostra apenas a taxa
  de atualização real da tela.
- **Meus Jogos**: lista apps com tela inicial visíveis via `<queries>` (sem `QUERY_ALL_PACKAGES`) que se
  declaram jogo; jogos que não aparecem podem ser adicionados manualmente.
- **Monitoramento**: a leitura só roda com a tela visível, no intervalo escolhido (2/3/5/10 s).

## Executar no Android Studio

1. Instale o Android Studio (Koala 2024.1 ou mais novo) com JDK 17 (já incluso).
2. `File > Open` e escolha a pasta `TurboXGameBooster`.
3. Aguarde o *Gradle Sync* (baixa o Gradle 8.9 e o SDK 35; o Studio oferece instalar o que faltar).
4. Conecte um aparelho com depuração USB ou crie um emulador (API 26+) e clique em **Run ▶**.

## Gerar o APK

**Debug (teste, instalável direto):**
```
./gradlew assembleDebug
```
Saída: `app/build/outputs/apk/debug/app-debug.apk`
(No Windows: `gradlew.bat assembleDebug`. No Studio: `Build > Build APK(s)`.)

**Release (assinado):**
1. `Build > Generate Signed App Bundle / APK > APK` e crie a keystore, **ou** crie manualmente
   `keystore.properties` na raiz:
   ```
   storeFile=/caminho/turbox.jks
   storePassword=...
   keyAlias=turbox
   keyPassword=...
   ```
2. `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`
   (sem `keystore.properties` o release sai **sem assinatura** e não instala).

Guarde a keystore e as senhas em local seguro: sem elas não é possível publicar atualizações.

## Observações

- Este código não foi compilado no ambiente em que foi escrito (sem SDK Android). Foi revisado linha a
  linha, mas se o primeiro build apontar algum erro, envie a mensagem para correção.
- A política de privacidade (`PrivacyScreen`) tem um campo "Contato" a preencher antes de publicar em loja.
- Próximas etapas sugeridas: testes unitários dos modelos/ViewModels, ícones/fonte personalizados, textos
  em `strings.xml` (hoje em português dentro do código) e revisão de políticas da Google Play.

## Gerar o APK sem Android Studio (GitHub Actions)

1. Crie um repositório no GitHub e envie o conteúdo desta pasta (inclusive `.github/`).
2. Abra a aba **Actions**, rode **Gerar APK** (ou espere o build do push terminar).
3. Abra a execução concluída e baixe **TurboX-debug-apk** na seção *Artifacts* (um .zip com o `app-debug.apk`).
4. Passe o APK para o celular e instale (permita "instalar apps desconhecidos" quando o Android pedir).
